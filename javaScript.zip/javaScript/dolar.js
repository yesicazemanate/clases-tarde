let dolares = prompt("ingrese dolares")
let pesosColombianos = dolares * 4115.75
alert(`${dolares} dolares son ${pesosColombianos} en pesos colombianos`)