// metodo reduce
/*const array = [1, 2, 3, 4, 5, 6, 7, 8, 9]
const inicial = 0
const result = array.reduce((acu, suma) => acu + suma, inicial);
console.log(result)*/
// metodo reverse
/*const array1 = ["one", "two", "three", "four", "five"]
console.log("array1: ", array1)
const reversed = array1.reverse();
console.log("arrayReverse: ", reversed);*/
//metodo shift
/*let comida = ["sancocho", "arroz", "frijol", "caldo"]
let eliminado = comida.shift();
console.log(comida)*/

